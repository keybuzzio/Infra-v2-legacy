#!/usr/bin/env bash
#
# apply_base_os_to_all.sh - Appliquer le Module 2 (Base OS & Sécurité)
#                           à tous les serveurs listés dans servers.tsv
#
# Usage:
#   ./apply_base_os_to_all.sh /chemin/vers/servers.tsv
#
# Pré-requis :
#  - être exécuté depuis install-01
#  - accès SSH root sans mot de passe vers tous les serveurs
#  - base_os.sh présent dans le même répertoire que ce script

set -uo pipefail

TSV_FILE="${1:-./servers.tsv}"
BASE_OS_SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_OS_SCRIPT="${BASE_OS_SCRIPT_DIR}/base_os.sh"

# Détecter la clé SSH à utiliser
SSH_KEY_OPTS=""
if [[ -f "${HOME}/.ssh/keybuzz_infra" ]]; then
    SSH_KEY_OPTS="-i ${HOME}/.ssh/keybuzz_infra"
elif [[ -f "${HOME}/.ssh/id_ed25519" ]]; then
    SSH_KEY_OPTS="-i ${HOME}/.ssh/id_ed25519"
elif [[ -f "${HOME}/.ssh/id_rsa" ]]; then
    SSH_KEY_OPTS="-i ${HOME}/.ssh/id_rsa"
fi

if [[ ! -f "${TSV_FILE}" ]]; then
  echo "❌ Fichier TSV introuvable: ${TSV_FILE}"
  exit 1
fi

if [[ ! -f "${BASE_OS_SCRIPT}" ]]; then
  echo "❌ base_os.sh introuvable dans ${BASE_OS_SCRIPT_DIR}"
  exit 1
fi

echo "=============================================================="
echo " [KeyBuzz] Module 2 - Application Base OS & Sécurité"
echo " Fichier d'inventaire : ${TSV_FILE}"
echo " Script base_os       : ${BASE_OS_SCRIPT}"
echo "=============================================================="

# On suppose le header :
# ENV  IP_PUBLIQUE  HOSTNAME  IP_PRIVEE  FQDN  USER_SSH  POOL  ROLE  SUBROLE  DOCKER_STACK  CORE  NOTES
# séparé par TAB

# Utiliser exec pour ouvrir le fichier et éviter les problèmes de redirection
exec 3< "${TSV_FILE}"

while IFS=$'\t' read -r ENV IP_PUBLIQUE HOSTNAME IP_PRIVEE FQDN USER_SSH POOL ROLE SUBROLE DOCKER_STACK CORE NOTES <&3; do
  # Skip header
  if [[ "${ENV}" == "ENV" ]]; then
    continue
  fi

  # On ne traite que env=prod (par défaut)
  if [[ "${ENV}" != "prod" ]]; then
    continue
  fi

  TARGET_USER="${USER_SSH:-root}"
  TARGET_IP="${IP_PRIVEE}"

  if [[ -z "${TARGET_IP}" ]]; then
    echo "⚠️  IP privée vide pour ${HOSTNAME}, on saute."
    continue
  fi

  echo "--------------------------------------------------------------"
  echo "▶ Traitement serveur : ${HOSTNAME} (${TARGET_IP})"
  echo "   Rôle: ${ROLE} / ${SUBROLE} | Pool: ${POOL}"
  echo "--------------------------------------------------------------"

  # Copier base_os.sh sur le serveur
  if scp ${SSH_KEY_OPTS} -q -o StrictHostKeyChecking=accept-new \
      "${BASE_OS_SCRIPT}" "${TARGET_USER}@${TARGET_IP}:/root/base_os.sh" 2>/dev/null; then
    
    # Rendre exécutable & lancer avec le bon rôle
    if ssh ${SSH_KEY_OPTS} -o BatchMode=yes -o StrictHostKeyChecking=accept-new \
        "${TARGET_USER}@${TARGET_IP}" \
        "chmod +x /root/base_os.sh && /root/base_os.sh '${ROLE}' '${SUBROLE}'" 2>&1; then
      echo "✅ Serveur ${HOSTNAME} (${TARGET_IP}) traité avec succès."
    else
      echo "❌ Erreur lors de l'exécution sur ${HOSTNAME} (${TARGET_IP})"
    fi
  else
    echo "❌ Erreur lors de la copie vers ${HOSTNAME} (${TARGET_IP})"
  fi
  echo
done

exec 3<&-

echo "=============================================================="
echo "🎉 [KeyBuzz] Module 2 appliqué sur tous les serveurs prod."
echo "=============================================================="

