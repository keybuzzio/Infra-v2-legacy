# ssh_install01.ps1 - Connexion à install-01
# Usage: .\ssh_install01.ps1 "commande"
#        .\ssh_install01.ps1  # Session interactive

param(
    [Parameter(Mandatory=$false)]
    [string]$Command = ""
)

$INSTALL_01_IP = "91.98.128.153"
$SSH_USER = "root"
$SSH_KEY = "$PSScriptRoot\..\..\SSH\keybuzz_infra"

# Vérifier la clé SSH
if (-not (Test-Path $SSH_KEY)) {
    Write-Host "❌ Clé SSH introuvable : $SSH_KEY" -ForegroundColor Red
    exit 1
}

# Construire la commande SSH
$sshCmd = "ssh -i `"$SSH_KEY`" -o StrictHostKeyChecking=accept-new ${SSH_USER}@${INSTALL_01_IP}"

if ($Command) {
    Write-Host "Connexion a install-01 et execution de la commande..." -ForegroundColor Cyan
    Write-Host "Vous devrez entrer le passphrase une fois" -ForegroundColor Yellow
    Invoke-Expression "$sshCmd `"$Command`""
} else {
    Write-Host "Connexion interactive a install-01..." -ForegroundColor Cyan
    Write-Host "Vous devrez entrer le passphrase une fois" -ForegroundColor Yellow
    Invoke-Expression $sshCmd
}

