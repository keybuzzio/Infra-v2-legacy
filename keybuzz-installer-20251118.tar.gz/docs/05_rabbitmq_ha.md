# Module 5 — RabbitMQ HA

## À venir

Documentation complète pour l'installation du cluster RabbitMQ Quorum.

