# Module 9 — K3s HA

## À venir

Documentation complète pour l'installation du cluster K3s (control plane + workers).

