# Module 4 — Redis HA

## À venir

Documentation complète pour l'installation du cluster Redis HA avec Sentinel.

