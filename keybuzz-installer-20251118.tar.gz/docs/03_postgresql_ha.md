# Module 3 — PostgreSQL HA (Patroni RAFT)

## À venir

Documentation complète pour l'installation du cluster PostgreSQL HA avec Patroni RAFT.

